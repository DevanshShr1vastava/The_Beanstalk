from django.apps import AppConfig


class Eva01Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'eva01'
